var renderer = null;

var stage = null;


function onInit()
{
       renderer = PIXI.autoDetectRenderer(860, 730,{backgroundColor : 0xFFFFFF, antialias : true});
       document.body.appendChild(renderer.view);
       stage = new PIXI.Container();

       render();

       var game = new Game(stage);

       window.addEventListener("game", game.onGame.bind(game), false);


       window.dispatchEvent(new CustomEvent('game', {'detail': {'type':'load_assets', 'value':null}}));

}


function render()
{
       requestAnimationFrame(render);
       renderer.render(stage);
}


window.addEventListener("load", onInit, false);