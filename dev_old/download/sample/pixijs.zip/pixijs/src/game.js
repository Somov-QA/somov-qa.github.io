function Game(mainStage)
{

       this.mainStage = mainStage;

}


Game.prototype = {


       constructor: Game,


       assets: null,

       menu: null,

       

       onGame: function(event)
       {

               switch(event.detail.type)
               {

                       case 'load_assets':
                       {

                               this.loadAssets();

                               break;

                       }

                       default:

                               break;

               }

       },


       loadAssets: function()
       {

               var loader = new PIXI.loaders.Loader();

               loader.add('image',"./assets/image.png");

               loader.once('complete', this.onLoadedComplete.bind(this));

               loader.load();

       },


       onLoadedComplete: function(loader, res)
       {

               this.assets = new Object();

               this.assets["image"] = res.image.texture;


               this.menuCreate();

       },


       menuCreate: function()
       {

               this.menu = new Menu(this.assets);

               this.menu.worldCreate();

               this.mainStage.addChild(this.menu.stage);

       }

}