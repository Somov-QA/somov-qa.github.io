function Menu(assets)
{

       this.stage = new PIXI.Container();

       this.assets = assets;

}


Menu.prototype = {

       constructor: Menu,


       worldCreate: function()
       {

               var sprite = new PIXI.Sprite(this.assets["image"]);

               this.stage.addChild(sprite);

       },


       worldDestroy: function()
       {


       }


}