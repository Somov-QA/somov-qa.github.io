var game;

window.onload = function() {        
       game = new Phaser.Game(800, 600, Phaser.AUTO, "");
       game.state.add("PlayGame", PlayGame);
       game.state.start("PlayGame");
}


var PlayGame = function(game) { };

PlayGame.prototype = {

       preload: function()
       {
               game.load.image("image", "./assets/image.png");
       },


       create: function()
       {  
               game.stage.backgroundColor = "#000044";
               game.add.sprite(0, 0, 'image');

       },


       update:function()
       {


       },


       render: function()
       {


       }

}