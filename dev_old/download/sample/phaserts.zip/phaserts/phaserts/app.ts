﻿/// <reference path="./src/preloader.ts" />

/// <reference path="./src/menu.ts" />


class Game extends Phaser.Game {

    constructor() {

        super(860, 730, Phaser.CANVAS, "content", PreloaderState);

        this.state.add("MenuState", MenuState);

    }

}


window.onload = () => {

    var game = new Game();

};