﻿class MenuState extends Phaser.State {


    sound1: Phaser.Sound;


    preload() { }


    create() {

        this.createBackground();

    }


    update() { }


    render() { }


    createBackground() {

        var background: Phaser.Sprite = new Phaser.Sprite(this.game, 0, 0, 'image');

        this.stage.addChild(background);

    }

}

