﻿class PreloaderState extends Phaser.State {


    progressText: Phaser.Text;


    preload() { }


    create() {

        this.stage.backgroundColor = "#FFFFFF";


        this.load.onLoadStart.add(this.onLoadStart, this);

        this.load.onFileComplete.add(this.onFileComplete, this);

        this.load.onLoadComplete.add(this.onLoadComplete, this);


        this.load.image('image', './assets/image.png');

        this.load.start();

    }



    update() { }


    render() { }



    onLoadStart() {

        this.progressText = this.game.add.text(0, 0, "File Complete: 0%", { font: "24px Arial", fill: "#000000", align: "center" });

    }


    onFileComplete(progress, cacheKey, success, totalLoaded, totalFiles) {

        this.progressText.text = "File Complete: " + progress + "% - " + totalLoaded + " out of " + totalFiles;

    }


    onLoadComplete() {

        this.game.state.start("MenuState");

    }

}