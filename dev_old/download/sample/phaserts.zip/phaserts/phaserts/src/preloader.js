var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var PreloaderState = (function (_super) {
    __extends(PreloaderState, _super);
    function PreloaderState() {
        _super.apply(this, arguments);
    }
    PreloaderState.prototype.preload = function () { };
    PreloaderState.prototype.create = function () {
        this.stage.backgroundColor = "#FFFFFF";
        this.load.onLoadStart.add(this.onLoadStart, this);
        this.load.onFileComplete.add(this.onFileComplete, this);
        this.load.onLoadComplete.add(this.onLoadComplete, this);
        this.load.image('image', './assets/image.png');
        this.load.start();
    };
    PreloaderState.prototype.update = function () { };
    PreloaderState.prototype.render = function () { };
    PreloaderState.prototype.onLoadStart = function () {
        this.progressText = this.game.add.text(0, 0, "File Complete: 0%", { font: "24px Arial", fill: "#000000", align: "center" });
    };
    PreloaderState.prototype.onFileComplete = function (progress, cacheKey, success, totalLoaded, totalFiles) {
        this.progressText.text = "File Complete: " + progress + "% - " + totalLoaded + " out of " + totalFiles;
    };
    PreloaderState.prototype.onLoadComplete = function () {
        this.game.state.start("MenuState");
    };
    return PreloaderState;
})(Phaser.State);
//# sourceMappingURL=preloader.js.map