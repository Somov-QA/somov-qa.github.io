var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var MenuState = (function (_super) {
    __extends(MenuState, _super);
    function MenuState() {
        _super.apply(this, arguments);
    }
    MenuState.prototype.preload = function () { };
    MenuState.prototype.create = function () {
        this.createBackground();
    };
    MenuState.prototype.update = function () { };
    MenuState.prototype.render = function () { };
    MenuState.prototype.createBackground = function () {
        var background = new Phaser.Sprite(this.game, 0, 0, 'image');
        this.stage.addChild(background);
    };
    return MenuState;
})(Phaser.State);
//# sourceMappingURL=menu.js.map