var scene;
var camera;
var light;
var cube;

var renderer;


window.onload = function() {        

       scene = new THREE.Scene();

       camera = new THREE.PerspectiveCamera( 75, window.innerWidth/window.innerHeight, 0.1, 1000 );
       camera.position.z = 5;

       light = new THREE.DirectionalLight(0xffffff);

       scene.add(light);


       var loader = new THREE.JSONLoader();

       loader.load('assets/cube.json', function (geometry, materials) {

               var material = new THREE.MultiMaterial( materials );

               cube = new THREE.Mesh( geometry, material );

               cube.rotation.y = -Math.PI/5;


               scene.add(cube);

               render();

       });


       renderer = new THREE.WebGLRenderer();
       renderer.setClearColor(new THREE.Color(0xEEEEEE));
       renderer.setSize( window.innerWidth, window.innerHeight );

       document.body.appendChild( renderer.domElement );

}


var render = function () {
       requestAnimationFrame( render );

       cube.rotation.x += 0.01;
       cube.rotation.y += 0.01;

       renderer.render(scene, camera);
};