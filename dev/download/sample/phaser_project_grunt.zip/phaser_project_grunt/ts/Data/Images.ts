class Images {
    public static ImagePhaser: string = 'phaser';
    
    public static preloadList: string[] = [
    	Images.ImagePhaser
    ];
}