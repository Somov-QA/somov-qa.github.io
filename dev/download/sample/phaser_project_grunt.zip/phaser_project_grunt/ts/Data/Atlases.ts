class Atlases {
    //public static AtlasName: string = 'atlas_name';
    
    public static preloadList: string[] = [
        //Atlases.AtlasName
    ];
}