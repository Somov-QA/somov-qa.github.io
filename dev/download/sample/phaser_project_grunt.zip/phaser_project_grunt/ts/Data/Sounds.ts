class Sounds {
    //public static SoundName: string = 'sound_name';

    public static preloadList: string[] = [
        //Sounds.SoundName
    ];
}