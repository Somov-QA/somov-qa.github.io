class Constants
{
    public static GAME_WIDTH: number            = 1280;
    public static GAME_HEIGHT: number           = 720;
}